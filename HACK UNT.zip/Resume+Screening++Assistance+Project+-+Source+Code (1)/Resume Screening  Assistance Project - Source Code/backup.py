# app.py
# General imports for Streamlit and environment variables
import streamlit as st
# import streamlit as st
# from dotenv import load_dotenv
# from utils import *
import uuid
from dotenv import load_dotenv
import os
import streamlit as st
# from dotenv import load_dotenv
from utils import *
# import uuid

# Libraries for NLP and language models
from langchain.llms import OpenAI, CTransformers
from langchain.prompts import PromptTemplate, FewShotPromptTemplate
from langchain.embeddings import OpenAIEmbeddings, SentenceTransformerEmbeddings
from langchain.vectorstores import FAISS, Pinecone
from langchain.chains import ConversationChain, LLMChain
from langchain.chains.conversation.memory import ConversationBufferMemory, ConversationSummaryMemory, ConversationBufferWindowMemory

# Libraries for handling files and data
# from pypdf import PdfReader
# Old import statement
# from PyPDF2 import PdfFileReader

# New import statement
from PyPDF2 import PdfReader

import pandas as pd
import uuid

# Additional utilities and specific functionalities
from streamlit_chat import message
from utils import *  # Assuming utils.py contains shared utility functions used across apps
# ... any other specific imports needed for your apps ...

# Load environment variables
load_dotenv()

# Set up the OpenAI API key (assuming it's used across multiple apps)
os.environ["OPENAI_API_KEY"] = st.secrets["OPENAI_API_KEY"]  # or your method of configuring the API key


# Import functions from utils.py (assuming they are defined there)
# from utils import email_summary, get_pdf_text, query_agent, generate_script,get_llm_response  # If the function name in utils.py is get_llm_response


# Load environment variables
load_dotenv()

# Set up Streamlit page configuration
st.set_page_config(page_title="Multi-Functional Platform", page_icon=":rocket:", layout="wide")

# Define main function to control app logic
#Creating session variables
# if 'unique_id' not in st.session_state:
#     st.session_state['unique_id'] =''
# import uuid

# ...

# Generate a unique ID for each uploaded file
# unique_id = uuid.uuid4().hex

# ...



def main():
    st.sidebar.title("Navigation")
    app_mode = st.sidebar.radio("Go to", ["Home", "Resume Screening", "Email Generation", "YouTube Script Writing",
                                          "Data Analysis", "Educational Tools", "Chatbot", "Q&A Interface", "Similarity Search"])
    if app_mode == "Home":
        st.subheader("Welcome to the Multi-Functional Platform")

        # Introduction to the platform
        st.write("""
            Welcome to our integrated platform where we offer a variety of functionalities 
            ranging from data analysis, content generation, educational tools, to interactive chatbots and more. 
            This platform aims to provide a comprehensive suite of tools for various business and educational needs.
        """)

        # Instructions on how to use the platform
        st.markdown("""
            ## How to Use the Platform
            - Use the sidebar to navigate between different applications.
            - Each application offers unique functionalities:
                - **Resume Screening:** Helps you in screening resumes efficiently.
                - **Email Generation:** Automatically generates emails based on input data.
                - **YouTube Script Writing:** Assists in creating scripts for YouTube videos.
                - **Data Analysis:** Analyze your data with our powerful tools.
                - **Educational Tools:** Interactive tools for education and learning.
                - **Chatbot:** Engage with our AI chatbot for queries and information.
                - **Q&A Interface:** Ask questions and get instant answers.
                - **Similarity Search:** Find similar items or concepts from a given input.
            - Follow the instructions within each application for specific functionalities.
        """)

        # Additional information or features
        st.markdown("""
            Feel free to explore the platform and utilize the tools as per your requirements.
            If you need any help or have feedback, please let us know.
        """)

        # Optionally, include images or additional interactive elements
        # st.image('path_to_image.png', caption='An insightful image.')


    elif app_mode == "Resume Screening":
         load_dotenv()
        #  st.set_page_config(page_title="Resume Screening Assistance")
        # st.title("HR - Resume Screening Assistance...💁 ")
         st.subheader("I can help you in resume screening process")
         st.subheader("I can help you in resume screening process")

         job_description = st.text_area("Please paste the 'JOB DESCRIPTION' here...",key="1")
         document_count = st.text_input("No.of 'RESUMES' to return",key="2")
        # Upload the Resumes (pdf files)
         pdf = st.file_uploader("Upload resumes here, only PDF files allowed", type=["pdf"],accept_multiple_files=True)

         submit=st.button("Help me with the analysis")

         if submit:
            with st.spinner('Wait for it...'):

                #Creating a unique ID, so that we can use to query and get only the user uploaded documents from PINECONE vector store
                st.session_state['unique_id']=uuid.uuid4().hex

            # Create a documents list out of all the user uploaded pdf files    
            final_docs_list = create_docs(pdf, st.session_state['unique_id'])

            # Displaying the count of resumes that have been uploaded
            st.write("*Resumes uploaded* : " + str(len(final_docs_list)))

            # Create embeddings instance
            embeddings = create_embeddings_load_data()

            # Push data to PINECONE
            push_to_pinecone("8a3d579d-a55b-4cfb-9fd9-f37307d2cb13", "us-west1-gcp-free", "test", embeddings, final_docs_list)

            # Fetch relevant documents from PINECONE
            relavant_docs = similar_docs(job_description, document_count, "8a3d579d-a55b-4cfb-9fd9-f37307d2cb13", "us-west1-gcp-free", "test", embeddings, st.session_state['unique_id'])

            # Introducing a line separator
            st.write(":heavy_minus_sign:" * 30)

            # For each item in relevant docs - we are displaying some info of it on the UI
            for item in range(len(relavant_docs)):
                st.subheader("👉 " + str(item + 1))

                # Displaying Filepath
                st.write("**File** : " + relavant_docs[item][0].metadata['name'])

                # Introducing Expander feature
                with st.expander('Show me 👀'):
                    st.info("**Match Score** : " + str(relavant_docs[item][1]))


                    # Gets the summary of the current item using 'get_summary' function that we have created which uses LLM & Langchain chain
                    summary = get_summary(relavant_docs[item][0])
                    st.write("**Summary** : " + summary)

            st.success("Hope I was able to save your time❤️")

            # elif app_mode == "Email Generation":
            #     # Insert the specific code for the Email Generation application here
            #     pass

            # elif app_mode == "YouTube Script Writing":
            #     # Insert the specific code for the YouTube Script Writing application here
            #     pass

            # elif app_mode == "Data Analysis":
            #     # Insert the specific code for the Data Analysis application here
            #     pass

            # elif app_mode == "Educational Tools":
            #     # Insert the specific code for the Educational Tools application here
            #     pass

            # elif app_mode == "Chatbot":
            #     # Insert the specific code for the Chatbot application here
            #     pass

            # elif app_mode == "Q&A Interface":
            #     # Insert the specific code for the Q&A Interface application here
            #     pass

            # elif app_mode == "Similarity Search":
            #     # Insert the specific code for the Similarity Search application here
            #     pass





    # ... continue for other applications ...

if __name__ == "__main__":
    main()
